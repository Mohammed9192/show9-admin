// ===================================================================
// SHOW9 STORE ADMIN DASHBOARD CONTROLLER (CONNECTED TO SUPABASE)
// ===================================================================

const SUPABASE_URL = 'https://qdmnygoppgprfpqjuhwl.supabase.co';
const SUPABASE_ANON_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFkbW55Z29wcGdwcmZwcWp1aHdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4MTQ4MzIsImV4cCI6MjEwNjM5MDgzMn0.tQ9-FP6LzFwt99mw-906FQjlt7MG5vRg8M-yUaWUZeI';

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// State Cache
let allOrders = [];
let allProducts = [];
let allRequests = [];
let activeOrderFilter = 'all';

// DOM Elements
const cloudStatusBadge = document.getElementById('cloudStatusBadge');
const cloudStatusText = document.getElementById('cloudStatusText');
const btnRefresh = document.getElementById('btnRefresh');

const statTotalOrders = document.getElementById('statTotalOrders');
const statPendingOrders = document.getElementById('statPendingOrders');
const statTotalSales = document.getElementById('statTotalSales');
const statTotalProducts = document.getElementById('statTotalProducts');
const badgePendingCount = document.getElementById('badgePendingCount');
const badgeRequestsCount = document.getElementById('badgeRequestsCount');

const ordersList = document.getElementById('ordersList');
const productsList = document.getElementById('productsList');
const requestsList = document.getElementById('requestsList');

const orderFilterPills = document.getElementById('orderFilterPills');
const orderSearchInput = document.getElementById('orderSearchInput');
const productSearchInput = document.getElementById('productSearchInput');

// Modals
const productModal = document.getElementById('productModal');
const productForm = document.getElementById('productForm');
const btnOpenAddProduct = document.getElementById('btnOpenAddProduct');
const btnCloseProductModal = document.getElementById('btnCloseProductModal');
const btnCancelProductModal = document.getElementById('btnCancelProductModal');

const receiptModal = document.getElementById('receiptModal');
const btnCloseReceiptModal = document.getElementById('btnCloseReceiptModal');
const btnConfirmReceiptModal = document.getElementById('btnConfirmReceiptModal');
const receiptModalImg = document.getElementById('receiptModalImg');
const receiptOrderTitle = document.getElementById('receiptOrderTitle');
const receiptCustomerInfo = document.getElementById('receiptCustomerInfo');
const btnDownloadReceipt = document.getElementById('btnDownloadReceipt');

const toastContainer = document.getElementById('toastContainer');
const orderPingAudio = document.getElementById('orderPingAudio');

// ================= INITIALIZATION =================
document.addEventListener('DOMContentLoaded', () => {
  setupTabs();
  setupFilterPills();
  setupModals();
  setupSearch();
  initSupabaseConnection();
  loadAllData();
  setupRealtimeListeners();
});

// ================= SUPABASE STATUS =================
async function initSupabaseConnection() {
  try {
    const { data, error } = await supabaseClient.from('categories').select('id').limit(1);
    if (!error) {
      cloudStatusBadge.classList.add('connected');
      cloudStatusText.textContent = 'متصل بالسحابة حياً 🟢';
    } else {
      cloudStatusText.textContent = 'تنبيه: تعذر الاتصال';
    }
  } catch (err) {
    cloudStatusText.textContent = 'غير متصل';
  }
}

// ================= LOAD ALL DATA =================
async function loadAllData() {
  await Promise.all([fetchOrders(), fetchProducts(), fetchRequests()]);
  updateStats();
}

btnRefresh.addEventListener('click', async () => {
  btnRefresh.querySelector('i').classList.add('fa-spin');
  await loadAllData();
  setTimeout(() => {
    btnRefresh.querySelector('i').classList.remove('fa-spin');
    showToast('تم تحديث البيانات بنجاح ✅', 'success');
  }, 400);
});

// ================= 1. ORDERS MANAGEMENT =================
async function fetchOrders() {
  try {
    const { data, error } = await supabaseClient
      .from('orders')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    allOrders = data || [];
    renderOrders();
  } catch (err) {
    console.error('Error fetching orders:', err);
    ordersList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <p>تعذر جلب الطلبات، يرجى التحقق من اتصال الإنترنت.</p>
      </div>`;
  }
}

function renderOrders() {
  const query = (orderSearchInput.value || '').trim().toLowerCase();
  
  let filtered = allOrders.filter((order) => {
    // Filter by tab pill
    if (activeOrderFilter === 'pending') {
      if (order.status !== 'قيد المراجعة' && order.status !== 'pending_review') return false;
    } else if (activeOrderFilter === 'preparing') {
      if (!order.status?.includes('تجهيز') && !order.status?.includes('preparing')) return false;
    } else if (activeOrderFilter === 'delivering') {
      if (!order.status?.includes('توصيل') && !order.status?.includes('delivering')) return false;
    } else if (activeOrderFilter === 'completed') {
      if (!order.status?.includes('تسليم') && !order.status?.includes('completed')) return false;
    }

    // Filter by search query
    if (query) {
      const matchName = (order.customer_name || '').toLowerCase().includes(query);
      const matchPhone = (order.phone || '').includes(query);
      const matchCity = (order.city || '').toLowerCase().includes(query);
      const matchId = (order.id || '').toLowerCase().includes(query);
      return matchName || matchPhone || matchCity || matchId;
    }

    return true;
  });

  if (filtered.length === 0) {
    ordersList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-box-open"></i>
        <p>لا توجد طلبات مطابقة حالياً.</p>
      </div>`;
    return;
  }

  ordersList.innerHTML = filtered.map((order) => {
    const orderDate = new Date(order.created_at).toLocaleString('ar-MR', {
      dateStyle: 'medium',
      timeStyle: 'short',
    });

    const items = Array.isArray(order.items) ? order.items : [];
    const itemsSummary = items
      .map((it) => `${it.product_name || it.name || 'سلعة'} (×${it.quantity || it.qty || 1})`)
      .join('، ');

    const cleanPhone = (order.phone || '').replace(/[^0-9]/g, '');
    const mrPhone = cleanPhone.startsWith('222') ? cleanPhone : '222' + cleanPhone;
    const whatsappMsg = encodeURIComponent(
      `مرحباً ${order.customer_name || 'عزيزي العميل'}، معك متجر شوّاقي (SHOW9). نود تأكيد طلبك رقم #${order.id.slice(0, 8)} بمبلغ ${Number(order.total_amount).toLocaleString()} أوقية لتسليمه في ${order.city || 'نواكشوط'}.`
    );

    const hasReceipt = Boolean(order.receipt_url);
    const badgeClass = getStatusBadgeClass(order.status);

    return `
      <div class="order-card" id="order-card-${order.id}">
        <div class="order-card-header">
          <div>
            <span class="order-id">#${order.id.slice(0, 8)}</span>
            <div class="order-date">${orderDate}</div>
          </div>
          <span class="status-badge ${badgeClass}">${order.status || 'قيد المراجعة'}</span>
        </div>

        <div class="order-customer">
          <span class="customer-name">${order.customer_name || 'عميل غير مسجل'}</span>
          <span class="customer-address">
            <i class="fa-solid fa-location-dot"></i>
            ${order.city || 'نواكشوط'} - ${order.address || 'العنوان غير محدد'}
          </span>
          <div class="customer-contact-row">
            <a href="https://wa.me/${mrPhone}?text=${whatsappMsg}" target="_blank" class="whatsapp-btn" title="محادثة واتساب مباشرة">
              <i class="fa-brands fa-whatsapp"></i>
              <span>واتساب (${order.phone || 'بدون رقم'})</span>
            </a>
          </div>
        </div>

        <div class="order-items-box">
          <div class="order-item-line">
            <span>المنتجات:</span>
            <strong>${itemsSummary || 'تفاصيل المنتجات المسجلة'}</strong>
          </div>
          <div class="order-item-line">
            <span>طريقة الدفع:</span>
            <span>${order.payment_method || 'بنكيلي (Bankily)'}</span>
          </div>
        </div>

        ${
          hasReceipt
            ? `
          <div class="receipt-action-box">
            <div style="display:flex; align-items:center; gap:8px;">
              <img src="${order.receipt_url}" class="receipt-thumb" alt="إشعار التحويل">
              <span style="font-size:12px; font-weight:700; color:#fff;">إشعار بنكيلي / سداد مرفق</span>
            </div>
            <button class="btn-view-receipt" onclick="inspectReceipt('${order.receipt_url}', '${order.id.slice(0, 8)}', '${order.customer_name}')">
              <i class="fa-solid fa-eye"></i>
              <span>فحص الإشعار</span>
            </button>
          </div>`
            : ''
        }

        <div class="order-total-row">
          <span class="total-label">المبلغ الكلي المطلوب:</span>
          <span class="total-value">${Number(order.total_amount).toLocaleString()} أوقية</span>
        </div>

        <div class="status-changer">
          <label>تغيير حالة الطلب:</label>
          <select onchange="updateOrderStatus('${order.id}', this.value)">
            <option value="قيد المراجعة" ${order.status === 'قيد المراجعة' ? 'selected' : ''}>⏳ قيد مراجعة الإشعار</option>
            <option value="جاري التجهيز" ${order.status === 'جاري التجهيز' ? 'selected' : ''}>📦 جاري تجهيز الطلب</option>
            <option value="خرج للتوصيل" ${order.status === 'خرج للتوصيل' ? 'selected' : ''}>🚚 خرج مع المندوب للتوصيل</option>
            <option value="تم التسليم" ${order.status === 'تم التسليم' ? 'selected' : ''}>✅ تم التسليم بنجاح</option>
            <option value="ملغي" ${order.status === 'ملغي' ? 'selected' : ''}>❌ إلغاء الطلب</option>
          </select>
        </div>
      </div>
    `;
  }).join('');
}

function getStatusBadgeClass(status) {
  if (!status) return 'pending';
  if (status.includes('تجهيز') || status.includes('preparing')) return 'preparing';
  if (status.includes('توصيل') || status.includes('delivering')) return 'delivering';
  if (status.includes('تسليم') || status.includes('completed')) return 'completed';
  return 'pending';
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    const { error } = await supabaseClient
      .from('orders')
      .update({ status: newStatus })
      .eq('id', orderId);

    if (error) throw error;

    const order = allOrders.find((o) => o.id === orderId);
    if (order) order.status = newStatus;

    showToast(`تم تغيير حالة الطلب إلى "${newStatus}" بنجاح`, 'success');
    renderOrders();
    updateStats();
  } catch (err) {
    console.error('Error updating order status:', err);
    showToast('حدث خطأ أثناء تعديل الحالة', 'error');
  }
}

// Receipt Inspection Popup
function inspectReceipt(url, orderId, customerName) {
  receiptModalImg.src = url;
  receiptOrderTitle.textContent = `طلب رقم #${orderId}`;
  receiptCustomerInfo.textContent = `المشتري: ${customerName}`;
  btnDownloadReceipt.href = url;
  receiptModal.classList.add('active');
}

// ================= 2. PRODUCTS MANAGEMENT =================
async function fetchProducts() {
  try {
    const { data, error } = await supabaseClient
      .from('products')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    allProducts = data || [];
    renderProducts();
  } catch (err) {
    console.error('Error fetching products:', err);
    productsList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <p>تعذر جلب المنتجات من السحابة.</p>
      </div>`;
  }
}

function renderProducts() {
  const query = (productSearchInput.value || '').trim().toLowerCase();

  const filtered = allProducts.filter((p) => {
    if (!query) return true;
    const matchName = (p.name || p.name_ar || '').toLowerCase().includes(query);
    const matchDesc = (p.description || '').toLowerCase().includes(query);
    return matchName || matchDesc;
  });

  if (filtered.length === 0) {
    productsList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-tags"></i>
        <p>لم يتم العثور على منتجات مطابقة.</p>
      </div>`;
    return;
  }

  productsList.innerHTML = filtered.map((prod) => {
    const imgUrl = prod.image_url || prod.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600';
    const isStock = prod.in_stock !== false;
    const catName = getCategoryLabel(prod.category_id || prod.category);

    return `
      <div class="product-card" id="prod-card-${prod.id}">
        <div class="product-image-wrap">
          <img src="${imgUrl}" alt="${prod.name || 'منتج'}" loading="lazy">
          <span class="product-stock-tag ${isStock ? '' : 'out'}">
            ${isStock ? 'متوفر بالمخزن' : 'نفذت الكمية'}
          </span>
        </div>

        <div class="product-info">
          <span class="product-category-name">${catName}</span>
          <h4 class="product-title">${prod.name || prod.name_ar || 'منتج شوّاقي'}</h4>
          <p style="font-size:12px; color:var(--text-secondary); line-height:1.5;">${(prod.description || '').slice(0, 75)}...</p>

          <div class="product-price-row">
            <span class="product-price">${Number(prod.price).toLocaleString()} أوقية</span>
          </div>

          <div class="product-card-actions">
            <button class="btn-edit-product" onclick="editProduct('${prod.id}')">
              <i class="fa-solid fa-pen-to-square"></i> تعديل
            </button>
            <button class="btn-delete-product" onclick="deleteProduct('${prod.id}', '${(prod.name || '').replace(/'/g, '')}')">
              <i class="fa-solid fa-trash-can"></i> حذف
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function getCategoryLabel(catId) {
  const map = {
    'clothing-men': 'أزياء رجالية',
    'clothing-women': 'أزياء نسائية',
    'perfumes': 'عطور ودخون',
    'electronics': 'إلكترونيات وهواتف',
    'watches': 'ساعات وإكسسوارات',
    'shoes': 'أحذية وحقائب',
  };
  return map[catId] || 'متنوعات';
}

// Add / Edit Product Submit
productForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const id = document.getElementById('prodFormId').value;
  const name = document.getElementById('prodFormName').value.trim();
  const price = Number(document.getElementById('prodFormPrice').value);
  const category_id = document.getElementById('prodFormCategory').value;
  const image_url = document.getElementById('prodFormImage').value.trim();
  const description = document.getElementById('prodFormDesc').value.trim();
  const in_stock = document.getElementById('prodFormStock').checked;

  const btnSave = document.getElementById('btnSaveProduct');
  btnSave.disabled = true;
  btnSave.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> جاري الحفظ...`;

  try {
    if (id) {
      // Update existing
      const { error } = await supabaseClient
        .from('products')
        .update({ name, price, category_id, image_url, description, in_stock })
        .eq('id', id);

      if (error) throw error;
      showToast('تم تحديث المنتج بنجاح ✨', 'success');
    } else {
      // Insert new
      const newId = `p-${Date.now().toString().slice(-6)}`;
      const { error } = await supabaseClient.from('products').insert([
        {
          id: newId,
          name,
          price,
          category_id,
          image_url,
          description,
          in_stock,
        },
      ]);

      if (error) throw error;
      showToast('تمت إضافة المنتج الجديد بنجاح إلى المتجر 🎉', 'success');
    }

    productModal.classList.remove('active');
    productForm.reset();
    await fetchProducts();
    updateStats();
  } catch (err) {
    console.error('Error saving product:', err);
    showToast('حدث خطأ أثناء حفظ المنتج، تأكد من صحة البيانات', 'error');
  } finally {
    btnSave.disabled = false;
    btnSave.innerHTML = `<i class="fa-solid fa-floppy-disk"></i> حفظ المنتج`;
  }
});

function editProduct(prodId) {
  const prod = allProducts.find((p) => p.id === prodId);
  if (!prod) return;

  document.getElementById('productModalTitle').textContent = 'تعديل بيانات المنتج';
  document.getElementById('prodFormId').value = prod.id;
  document.getElementById('prodFormName').value = prod.name || prod.name_ar || '';
  document.getElementById('prodFormPrice').value = prod.price || '';
  document.getElementById('prodFormCategory').value = prod.category_id || prod.category || 'clothing-men';
  document.getElementById('prodFormImage').value = prod.image_url || prod.image || '';
  document.getElementById('prodFormDesc').value = prod.description || '';
  document.getElementById('prodFormStock').checked = prod.in_stock !== false;

  productModal.classList.add('active');
}

async function deleteProduct(prodId, prodName) {
  if (!confirm(`هل أنتِ متأكدة من رغبتك في حذف المنتج: "${prodName}" من المتجر نهائياً؟`)) {
    return;
  }

  try {
    const { error } = await supabaseClient.from('products').delete().eq('id', prodId);
    if (error) throw error;

    allProducts = allProducts.filter((p) => p.id !== prodId);
    renderProducts();
    updateStats();
    showToast('تم حذف المنتج بنجاح 🗑️', 'warning');
  } catch (err) {
    console.error('Error deleting product:', err);
    showToast('تعذر حذف المنتج', 'error');
  }
}

// ================= 3. CUSTOM REQUESTS =================
async function fetchRequests() {
  try {
    const { data, error } = await supabaseClient
      .from('product_requests')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    allRequests = data || [];
    renderRequests();
  } catch (err) {
    console.error('Error fetching requests:', err);
    requestsList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-triangle-exclamation"></i>
        <p>تعذر جلب طلبات التوفير.</p>
      </div>`;
  }
}

function renderRequests() {
  if (allRequests.length === 0) {
    requestsList.innerHTML = `
      <div class="empty-state">
        <i class="fa-solid fa-wand-magic-sparkles"></i>
        <p>لا توجد طلبات توفير خاصة من الزبائن حتى الآن.</p>
      </div>`;
    return;
  }

  requestsList.innerHTML = allRequests.map((req) => {
    const cleanPhone = (req.phone || '').replace(/[^0-9]/g, '');
    const mrPhone = cleanPhone.startsWith('222') ? cleanPhone : '222' + cleanPhone;
    const whatsappMsg = encodeURIComponent(
      `مرحباً، بخصوص طلبك الخاص في متجر شوّاقي (${req.product_name || 'توفير منتج'})، يسعدنا إخبارك بتفاصيل التوفير والسعر.`
    );

    return `
      <div class="request-card">
        <div class="request-header">
          <span class="request-title">${req.product_name || 'طلب توفير خاص'}</span>
          <span class="status-badge pending">${req.status || 'جديد'}</span>
        </div>

        <p class="request-desc">${req.details || 'لا توجد تفاصيل إضافية'}</p>

        ${
          req.image_url
            ? `<img src="${req.image_url}" class="request-image-preview" alt="نموذج المنتج المطلوب">`
            : ''
        }

        <div style="margin-top:auto; padding-top:10px;">
          <a href="https://wa.me/${mrPhone}?text=${whatsappMsg}" target="_blank" class="whatsapp-btn" style="width:100%; justify-content:center;">
            <i class="fa-brands fa-whatsapp"></i>
            <span>تواصل مع العميل عبر الواتساب (${req.phone || 'بدون رقم'})</span>
          </a>
        </div>
      </div>
    `;
  }).join('');
}

// ================= STATS UPDATE =================
function updateStats() {
  statTotalOrders.textContent = allOrders.length;
  
  const pending = allOrders.filter((o) => o.status === 'قيد المراجعة' || o.status === 'pending_review');
  statPendingOrders.textContent = pending.length;
  badgePendingCount.textContent = pending.length;

  const totalSales = allOrders.reduce((sum, o) => sum + (Number(o.total_amount) || 0), 0);
  statTotalSales.textContent = `${totalSales.toLocaleString()} MRU`;

  statTotalProducts.textContent = allProducts.length;
  badgeRequestsCount.textContent = allRequests.length;
}

// ================= REAL-TIME LISTENERS =================
function setupRealtimeListeners() {
  supabaseClient
    .channel('orders-realtime')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'orders' }, (payload) => {
      console.log('New Order Received via Realtime:', payload);
      try {
        orderPingAudio.play().catch(() => {});
      } catch {}
      showToast(`🔔 طلب جديد وصل الآن من: ${payload.new.customer_name || 'عميل'}!`, 'success');
      fetchOrders();
      updateStats();
    })
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'orders' }, () => {
      fetchOrders();
      updateStats();
    })
    .subscribe();

  supabaseClient
    .channel('requests-realtime')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'product_requests' }, (payload) => {
      showToast(`✨ طلب "وفّر لي منتج" جديد وصل من: ${payload.new.phone}!`, 'warning');
      fetchRequests();
      updateStats();
    })
    .subscribe();
}

// ================= HELPERS & UI CONTROLS =================
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));

      btn.classList.add('active');
      const tabId = `tab-${btn.dataset.tab}`;
      const targetContent = document.getElementById(tabId);
      if (targetContent) targetContent.classList.add('active');
    });
  });
}

function setupFilterPills() {
  document.querySelectorAll('.filter-pill').forEach((pill) => {
    pill.addEventListener('click', () => {
      document.querySelectorAll('.filter-pill').forEach((p) => p.classList.remove('active'));
      pill.classList.add('active');
      activeOrderFilter = pill.dataset.filter;
      renderOrders();
    });
  });
}

function setupSearch() {
  orderSearchInput.addEventListener('input', () => renderOrders());
  productSearchInput.addEventListener('input', () => renderProducts());
}

function setupModals() {
  btnOpenAddProduct.addEventListener('click', () => {
    document.getElementById('productModalTitle').textContent = 'إضافة منتج جديد للمتجر';
    productForm.reset();
    document.getElementById('prodFormId').value = '';
    document.getElementById('prodFormStock').checked = true;
    productModal.classList.add('active');
  });

  const closeProd = () => productModal.classList.remove('active');
  btnCloseProductModal.addEventListener('click', closeProd);
  btnCancelProductModal.addEventListener('click', closeProd);

  const closeReceipt = () => receiptModal.classList.remove('active');
  btnCloseReceiptModal.addEventListener('click', closeReceipt);
  btnConfirmReceiptModal.addEventListener('click', closeReceipt);
}

function showToast(message, type = 'primary') {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  let icon = 'fa-circle-check';
  if (type === 'warning') icon = 'fa-triangle-exclamation';
  if (type === 'error') icon = 'fa-circle-xmark';

  toast.innerHTML = `<i class="fa-solid ${icon}"></i> <span>${message}</span>`;
  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}
